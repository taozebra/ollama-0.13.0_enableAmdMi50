package backend

import (
	_ "github.com/ollama/ollama/ml/backend/ggml"
)
