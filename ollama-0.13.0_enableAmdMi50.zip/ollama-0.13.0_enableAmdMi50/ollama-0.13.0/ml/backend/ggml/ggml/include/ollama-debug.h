#include "ggml.h"

#ifdef __cplusplus
extern "C" {
#endif

void ollama_debug(const struct ggml_tensor *tensor, bool verbose);

#ifdef __cplusplus
}
#endif
