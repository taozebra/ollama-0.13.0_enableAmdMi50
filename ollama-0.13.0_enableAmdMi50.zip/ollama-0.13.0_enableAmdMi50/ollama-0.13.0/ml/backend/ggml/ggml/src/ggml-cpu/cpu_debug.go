//go:build debug

package cpu

// #cgo CPPFLAGS: -DOLLAMA_DEBUG
import "C"
